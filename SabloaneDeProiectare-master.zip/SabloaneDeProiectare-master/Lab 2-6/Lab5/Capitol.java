
public class Capitol {
	String titlu;
	public Capitol(String titlu) {
		this.titlu=titlu;
	}
}
