

public abstract class Element {
public String name;
	public Element(String name) {
		this.name=name;
	}
	
	abstract void print();
}
