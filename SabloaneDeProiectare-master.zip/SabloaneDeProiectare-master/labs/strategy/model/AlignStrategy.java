
package strategy.model;

public interface AlignStrategy {
  public void print(String text);
}
